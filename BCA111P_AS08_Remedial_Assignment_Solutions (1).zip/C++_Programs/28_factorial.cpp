// Q28. Calculate factorial using a loop
#include <iostream>
using namespace std;

int main() {
    int n;
    unsigned long long factorial = 1;

    cout << "Enter a non-negative integer (0 to 20): ";
    cin >> n;

    if (n < 0 || n > 20) {
        cout << "Please enter a number from 0 to 20." << endl;
    } else {
        for (int i = 1; i <= n; i++) {
            factorial = factorial * i;
        }
        cout << "Factorial of " << n << " = " << factorial << endl;
    }

    return 0;
}
